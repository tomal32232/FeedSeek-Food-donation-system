<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('home');
});*/

Route::get('/profile', 'ProfileController@index')->name('view_profile');
Route::get('/profile{user}', 'ProfileController@edit')->name('edit_profile');
Route::post('/profile{user}', 'ProfileController@update')->name('update_profile');
Route::get('/profile/delete/{user}', 'ProfileController@delete')->name('delete_profile_photo');



Route::get('/donate_food', 'DonateFoodController@index')->name('donate_food');
Route::post('/donate_food{user}', 'DonateFoodController@store')->name('donate_food_action');

Route::get('/receive_food', 'ReceiveFoodController@index')->name('receive_food');
Route::post('/receive_food/{user}', 'ReceiveFoodController@store')->name('receive_food_action');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/logout', 'LoginController@logout')->name('logout');
Route::get('/mypost', 'MyPostController@index')->name('my_post.view');
Route::get('/singlepost/{id}', 'SinglePostController@index')->name('single_post.view');
Route::get('/singlepost/{id}/confirm', 'SinglePostController@confirm')->name('single_post.confirm');

Route::get('/notification', 'NotificationController@index')->name('notification.view');



