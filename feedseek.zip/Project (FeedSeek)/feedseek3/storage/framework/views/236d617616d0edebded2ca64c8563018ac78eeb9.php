<?php $__env->startSection('content'); ?>
<section class="home_banner_area">
           	<div class="container box_1620">
           		<div class="banner_inner d-flex align-items-center">
					<div class="banner_content">
						<div class="media">
							<div class="d-flex">
								<?php if($user->profile['image']): ?>
								<img src="images/profile_photos/<?php echo e($user->profile['image']); ?>" alt="" style="max-height: 500px; max-width: 500px;object-fit: cover;">
								<?php else: ?>
								<a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>"><img src="images/errors/upload_photo.png" alt="" style="max-height: 500px; max-width: 500px;object-fit: cover;"></a>
								<?php endif; ?>
							</div>
							<div class="media-body">
								
								<div class="personal_text">
									<h6>Name:</h6>
									<?php if($user->profile['full_name']): ?>
									<h4><?php echo e($user->profile['full_name']); ?></h4>
									<?php else: ?>
									<a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
									<?php endif; ?>
									<hr>
									<h6>Organization or restaurant:</h6>
									<?php if($user->profile['org_name']): ?>
									<h4><?php echo e($user->profile['org_name']); ?></h4>
									<?php else: ?>
									<a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
									<?php endif; ?>
									<hr>
									<h6>Address:</h6>
									<?php if($user->profile['address']): ?>
									<h4><?php echo e($user->profile['address']); ?></h4>
									<?php else: ?>
									<a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
									<?php endif; ?>
									<hr>
									
									<ul class="list basic_info">
										<li><a href="#"><i class="far fa-clock"></i>Member since: <?php echo e($user->profile['created_at']->format('F, Y')); ?></a></li>
										<li><a href="#"><i class="fas fa-phone"></i></i> <?php echo e($user->profile['phone_no']); ?> </a></li>
										<li><a href="#"><i class="far fa-envelope-open"></i> <?php echo e($user->email); ?></a></li>
									</ul>
									<ul class="list personal_social" style="float: right;">
										<li><a href="#"><i class="fas fa-facebook"></i></a></li>
										<li><a href="#"><i class="fas fa-twitter"></i></a></li>
										<li><a href="#"><i class="far fa-linkedin"></i></a></li>
									</ul>
									<ul>
									<a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>"  style="float: right; margin-top: 40px;">Edit profile  <i class="fas fa-user-edit"></i></a>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SWE\Project spring 2020\feedseek2\FeedSeek2\resources\views/profile.blade.php ENDPATH**/ ?>