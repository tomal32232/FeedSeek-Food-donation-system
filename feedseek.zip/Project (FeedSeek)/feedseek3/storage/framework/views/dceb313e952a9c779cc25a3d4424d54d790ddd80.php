<?php $__env->startSection('content'); ?>


    <div class="site-section bg-light">

      <div class="container">

        <div class="row">
          <div class="col-md-9 " data-aos="fade">
            <h2 class="font-weight-bold text-black">Posting as a recipient</h2>
            If you want to donate food<a href="<?php echo e(route('donate_food')); ?>"> <u style="color: red">Post as a donor</u></a>
          </div>
       
          <div class="col-md-12 col-lg-8 mb-5 ">
          
            
          
            <form method="post" action="<?php echo e(route('receive_food_action', $user->profile['user_id'])); ?>">
             <?php echo csrf_field(); ?>
             
              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="foodname">Food name</label>
                  <input type="text" id="foodname" name="foodname" class="form-control" placeholder="eg. Rice, Chicken">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="orgname">Organization/Restaurent name</label>
                  <input type="text" id="orgname" name="orgname" class="form-control" placeholder="eg. Facebook, Inc.">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="no_of_people">For how many people (Approximate)</label>
                  <input type="text" id="no_of_people" name="no_of_people" class="form-control" placeholder="eg. 150">
                </div>
              </div>


              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="dateee">Select date (Maximum)
                  </label>
                  <input type="date" id="dateee" name="date" class="form-control">
                </div>
              </div>

              <!-- <div class="row form-group mb-4">
                <div class="col-md-12"><h3>Location</h3></div>
                <div class="col-md-12 mb-3 mb-md-0">
                  
                <input type="text" class="form-control form-control-block search-input" id="autocomplete" name="address" placeholder="Location" onFocus="geolocate()">
                </div>
              </div> -->

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="info">Additional info (if any)
                  </label>
                  <textarea name="info" class="form-control" id="info" cols="30" rows="5"></textarea>
                </div>
              </div>

              <div class="row form-group" style="float: right;">
                <div class="col-md-12">
                  <input type="submit" value="Send request" class="btn btn-primary  py-2 px-5">
                </div>
              </div>

  
            </form>
          </div>

          <div class="col-lg-4">
            <div class="p-4 mb-3 bg-white">
              <h3 class="h5 text-black mb-3">Contact Info <a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>"><i class="fas fa-pencil-alt" style="float: right;"></i></a></h3>
              <p class="mb-0 font-weight-bold">Address</p>
              <?php if($user->profile['address']): ?>
              <p class="mb-4"><?php echo e($user->profile['address']); ?></p>
              <?php else: ?>
              <a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
              <?php endif; ?>
              <p class="mb-0 font-weight-bold">Phone</p>
              <?php if($user->profile['phone_no']): ?>
              <p class="mb-4"><a href="#"><?php echo e($user->profile['phone_no']); ?></a></p>
              <?php else: ?>
              <a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
              <?php endif; ?>

              <p class="mb-0 font-weight-bold">Email Address</p>
              <?php if($user->email): ?>
              <p class="mb-4"><a href="#"><?php echo e($user->email); ?></a></p>
              <?php else: ?>
              <a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
              <?php endif; ?>

            </div>
            
            <div class="p-4 mb-3 bg-white">
              <h3 class="h5 text-black mb-3">More Info <a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>"><i class="fas fa-pencil-alt" style="float: right;"></i></a></h3>
              <?php if($user->profile['additional_info']): ?>
              <p class="mb-4"><?php echo e($user->profile['additional_info']); ?></p>
              <?php else: ?>
              No information available.<br>
              <a href="<?php echo e(route('edit_profile', Auth::user()->id)); ?>">Edit profile</a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>

                
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SWE\Project spring 2020\FeedSeek3\feedseek3\resources\views/receive_food.blade.php ENDPATH**/ ?>