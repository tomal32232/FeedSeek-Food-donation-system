<?php $__env->startSection('content'); ?>
<section class="home_banner_area">
           	
	<div class="container mt-5">
		<div class="row">
			<div class="col">
				<div class="personal_text">
					<h6>Food Name:</h6>
					<h4><?php echo e($post->foodname); ?></h4>
					<hr>
											

					<h6>Organization:</h6>
					<h4><?php echo e($post->orgname); ?></h4>
					<hr>
											

					<h6>For how many people:</h6>
					<h4><?php echo e($post->no_of_people); ?></h4>
					<hr>

					<h6>Expire date:</h6>
					<h4><?php echo e($post->date); ?></h4>
					<hr>

					<h6>Additional info:</h6>
					<h4><?php echo e($post->info); ?></h4>
					<hr>

					<h6>Request submitted</h6>
					<h4><?php echo e($post->request); ?></h4>
					<hr>
				</div>
			</div>



			<div class="col">
				<div class="personal_text">
					<h6>Donor Name:</h6>
					<h4><?php echo e($post->user->profile['full_name']); ?></h4>
					<hr>
											

					<h6>Organization or restaurant:</h6>
					<h4><?php echo e($post->user->profile['org_name']); ?></h4>
					<hr>
											

					<h6>Address:</h6>
					<h4><?php echo e($post->user->profile['address']); ?></h4>
					<hr>

					<h6>Phone:</h6>
					<h4><?php echo e($post->user->profile['phone_no']); ?></h4>
					<hr>

					<h6>Email:</h6>
					<h4><?php echo e($post->user['email']); ?></h4>
					<hr>

					<h6>Member since:</h6>
					<h4><?php echo e($post->user->profile['created_at']->format('F, Y')); ?></h4>
					<hr>
				</div>
			</div>

		</div>
			<a href="<?php echo e(route ('single_post.confirm', $post->id)); ?>" class="btn btn-primary py-3 btn-block"><span class="h5">+</span> Confirm</a>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SWE\Project spring 2020\feedseek2\FeedSeek2\resources\views/single_post.blade.php ENDPATH**/ ?>