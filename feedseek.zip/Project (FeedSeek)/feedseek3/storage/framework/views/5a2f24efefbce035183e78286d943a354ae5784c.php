<?php $__env->startSection('content'); ?>

<div class="site-section bg-light">
  <div class="container">
    <div class="row justify-content-start text-left mb-5">
      <div class="col-md-9" data-aos="fade">
        <h2 class="font-weight-bold text-black">Notification</h2>
      </div>
      <div class="col-md-3" data-aos="fade" data-aos-delay="200">
        <a href="#" class="btn btn-primary py-3 btn-block"><span class="h5">+</span> Create new</a>
      </div>
    </div>

    <div class="row" data-aos="fade">
      <div class="col-md-12">
        <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($request->requested_to==$myself->id): ?>
            	<div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
                <div class="mb-4 mb-md-0 mr-5">
               		<div class="job-post-item-header d-flex align-items-center">
                 		<h2 class="mr-3 text-black h4"><?php echo e($request->user['username']); ?> responded to your post and ready to receive your food.</h2>
                 			
                      
                 			
                	</div>
               		<div class="job-post-item-header d-flex align-items-center">
                        <p><?php echo e($request->created_at->diffForHumans()); ?></p>
                      </div>
               		
               		
              	</div>

              	<div class="ml-auto mt-auto">
                	<a href="job-single.html" class="btn btn-danger py-2">Cancel</a>
                	<a href="job-single.html" class="btn btn-primary py-2">Confirm</a>
                </div>
           		</div>
          <?php else: ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           			
           	

      </div>
    </div>
      

    <div class="row mt-5">
      <div class="col-md-12 text-center">
        <div class="site-block-27">
          <ul>
            <li><a href="#"><i class="icon-keyboard_arrow_left h5"></i></a></li>
            <li class="active"><span>1</span></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li><a href="#"><i class="icon-keyboard_arrow_right h5"></i></a></li>
          </ul>
        </div>
      </div>
    </div>


  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SWE\Project spring 2020\FeedSeek3\feedseek3\resources\views/notification.blade.php ENDPATH**/ ?>