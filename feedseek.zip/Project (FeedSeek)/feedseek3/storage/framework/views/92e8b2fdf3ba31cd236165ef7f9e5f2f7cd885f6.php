<?php $__env->startSection('content'); ?>
<div class="site-blocks-cover" style="background-image: url(images/cover.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
  <div class="container">
    <div class="row row-custom align-items-center">
      <div class="col-md-10">
        <h1 class="mb-2 text-black w-75"><span class="font-weight-bold">We Can</span> Help To Save The World</h1>
        <div class="job-search">
          <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active py-3" id="pills-job-tab" data-toggle="pill" href="#pills-job" role="tab" aria-controls="pills-job" aria-selected="true">Find Donor</a>
            </li>
            <li class="nav-item">
              <a class="nav-link py-3" id="pills-candidate-tab" data-toggle="pill" href="#pills-candidate" role="tab" aria-controls="pills-candidate" aria-selected="false">Find Recepient</a>
            </li>
          </ul>
          <div class="tab-content bg-white p-4 rounded" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-job" role="tabpanel" aria-labelledby="pills-job-tab">
              <form action="#" method="post">
                <div class="row">
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control" placeholder="eg. Web Developer">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="select-wrap">
                      <span class="icon-keyboard_arrow_down arrow-down"></span>
                      <select name="" id="" class="form-control">
                        <option value="">Category</option>
                        <option value="fulltime">Full Time</option>
                        <option value="fulltime">Part Time</option>
                        <option value="freelance">Freelance</option>
                        <option value="internship">Internship</option>
                        <option value="internship">Termporary</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control form-control-block search-input" id="autocomplete" placeholder="Location" onFocus="geolocate()">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="submit" class="btn btn-primary btn-block" value="Search">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="pills-candidate" role="tabpanel" aria-labelledby="pills-candidate-tab">
              <form action="#" method="post">
                <div class="row">
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control" placeholder="eg. Carl Smith">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="select-wrap">
                      <span class="icon-keyboard_arrow_down arrow-down"></span>
                      <select name="" id="" class="form-control">
                        <option value="">Category</option>
                        <option value="fulltime">Full Time</option>
                        <option value="fulltime">Part Time</option>
                        <option value="freelance">Freelance</option>
                        <option value="internship">Internship</option>
                        <option value="internship">Termporary</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control form-control-block search-input" id="autocomplete" placeholder="Location" onFocus="geolocate()">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="submit" class="btn btn-primary btn-block" value="Search">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>







<div class="site-section bg-light">
  <div class="container">
    <div class="row justify-content-start text-left mb-5">
      <div class="col-md-9" data-aos="fade">
        <h2 class="font-weight-bold text-black">Recent Post</h2>
      </div>
      <div class="col-md-3" data-aos="fade" data-aos-delay="200">
        <a href="<?php echo e(route('receive_food')); ?>" class="btn btn-primary py-3 btn-block"><span class="h5"></span> I need food</a>
      </div>
    </div>
    <div class="row" data-aos="fade">
      <div class="col-md-12">
      <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($post->status==1 || $post->status==2): ?>
            <div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
              <div class="mb-4 mb-md-0 mr-5">
                <div class="job-post-item-header d-flex align-items-center">
                  <h2 class="mr-3 text-black h4"><?php echo e($post->foodname); ?></h2>
                  <?php if($post->status==1): ?>
                    <h5 style="color: red"><i class="fas fa-user-alt"></i>For donation</h5>
                  <?php else: ?>
                    <h5 style="color: red"><i class="fas fa-user-alt"></i>Recipient</h5>
                  <?php endif; ?>
                </div>
                <div class="job-post-item-header d-flex align-items-center">
                  <div><h5>About <?php echo e($post->no_of_people); ?> people</h5></div>
                  <?php if($post->status==1): ?>
                    <div><h6>&nbsp&nbsp&nbsp&nbsp&nbspMaximum Date: <?php echo e($post->date); ?></h6></div>
                  <?php else: ?>
                    <div><h6>&nbsp&nbsp&nbsp&nbsp&nbspOn: <?php echo e($post->date); ?></h6></div>
                  <?php endif; ?>
                </div>
                <div class="job-post-item-body d-block d-md-flex">
                  <div class="badge-wrap">
                    <span class="bg-primary text-white badge py-2 px-2" style="border-radius: 2px"><?php echo e($post->orgname); ?></span>
                  </div>
                </div>
                <div class="job-post-item-header d-flex align-items-center">
                  <div><h5><i class="fas fa-user-alt"></i><?php echo e($post->user->profile['address']); ?></h5></div>
                </div>
              </div>

              <div class="ml-auto mt-auto">
                <a href="#" class="btn btn-secondary rounded-circle btn-favorite text-gray-500"><span class="icon-heart"></span></a>
                <a href="<?php echo e(route ('single_post.view', $post->id)); ?>" class="btn btn-primary py-2">View details</a>
                <?php if($post->status==1): ?>
                <a href="<?php echo e(route ('single_post.confirm', $post->id)); ?>" class="btn btn-primary py-2">I want to receive</a>
                <?php else: ?>
                <a href="job-single.html" class="btn btn-primary py-2">I want to donate</a>
                <?php endif; ?>
              </div>
            </div>
          <?php else: ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <?php endif; ?>
      </div>
    </div>
      

        

    <div class="row mt-5">
      <div class="col-md-12 text-center">
        <div class="site-block-27">
          <ul>
            <li><a href="#"><i class="icon-keyboard_arrow_left h5"></i></a></li>
            <li class="active"><span>1</span></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li><a href="#"><i class="icon-keyboard_arrow_right h5"></i></a></li>
          </ul>
        </div>
      </div>
    </div>


  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SWE\Project spring 2020\feedseek2\resources\views/home.blade.php ENDPATH**/ ?>