<?php $__env->startSection('content'); ?>


    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
       
          <div class="col-md-12 col-lg-8 mb-5">
          
            
          
            <form method="post" action="<?php echo e(route('update_profile', $user->profile['user_id'])); ?>" class="p-5 bg-white" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
      
              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="full_name">Your Name:</label>
                  <input type="text" id="full_name" name="full_name" class="form-control" placeholder="eg. John Thomas" value="<?php echo e($user->profile['full_name']); ?>">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="org_name">Organization/Restaurent name:</label>
                  <input type="text" id="org_name" name="org_name" class="form-control" placeholder="eg. Jagoo foundation" value="<?php echo e($user->profile['org_name']); ?> ">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="designation">Your designation at this organization:</label>
                  <input type="text" id="designation" name="designation" class="form-control" placeholder="eg. Member" value="<?php echo e($user->profile['designation']); ?>">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="address">Contact Address:</label>
                  <input type="text" name="address" class="form-control form-control-block search-input" id="autocomplete" placeholder="Location" onFocus="geolocate()" value="<?php echo e($user->profile['address']); ?>">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="phone_no">Phone:</label>
                  <input type="text" id="phone_no" name="phone_no" class="form-control" placeholder="eg. 01731237218" value="<?php echo e($user->profile['phone_no']); ?>">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="additional_info">Additional information about your organization :</label>
                  <textarea name="additional_info" class="form-control" id="additional_info" cols="30" rows="5"></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input type="submit" value="Post" class="btn btn-primary  py-2 px-5" style="float: right;">
                </div>
              </div>

          </div>

          <div class="col-lg-4">
            <div class="p-4 mb-3 bg-white">
              <?php if($user->profile['image']): ?>
              <img src="images/profile_photos/<?php echo e($user->profile['image']); ?>" id="profile-img-tag" alt="profile photo" width="200px" style="margin-right: auto; margin-left: auto; display: block; margin-bottom: 20px;">
              <a href="<?php echo e(route('delete_profile_photo', Auth::user()->id)); ?>">
              Remove photo
              </a>
              <?php else: ?>
              <img src="images/errors/upload_photo.png" id="profile-img-tag" alt="profile photo" width="200px" style="margin-right: auto; margin-left: auto; display: block; margin-bottom: 20px;">
              <?php endif; ?>
              <input type="file" name="image" id="profile-img">




              <script type="text/javascript">
                  function readURL(input) {
                      if (input.files && input.files[0]) {
                          var reader = new FileReader();
                          
                          reader.onload = function (e) {
                              $('#profile-img-tag').attr('src', e.target.result);
                          }
                          reader.readAsDataURL(input.files[0]);
                      }
                  }
                  $("#profile-img").change(function(){
                      readURL(this);
                  });
              </script>
            </div>
          </div>

                        
        </div>
      </div>
      </form>

            <!-- <form method="post" action="<?php echo e(route('delete_profile_photo', Auth::user()->id)); ?>">
              <?php echo csrf_field(); ?>
              <input type="submit" name="" class="col-lg-4">
            </form> -->
            
    </div>

                
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SWE\Project spring 2020\feedseek2\FeedSeek2\resources\views/edit_profile.blade.php ENDPATH**/ ?>