<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donation extends Model
{
    /*protected $fillable = [
        'foodname', 'orgname', 'no_of_people', 'date', 'info',
    ];*/

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function Request()
    {
        return $this->hasMany(Request::class);
    }
}


