<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Requests extends Model
{
    
    public function User()
    {
        return $this->belongsTo(User::class);
    }
    public function Donation()
    {
        return $this->belongsTo(Donation::class);
    }

}
