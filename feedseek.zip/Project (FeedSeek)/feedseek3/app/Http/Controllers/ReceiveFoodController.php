<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Donation;

use App\User;
use App\profile;
use Auth;

class ReceiveFoodController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->user()) 
        {
            $user = User::find(Auth::id());
             // return redirect(route('donate_food'));
            return view('receive_food',compact('user'));

        }
        else
        {
               return redirect(route('login'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $id)
    {
        $post = new Donation;
       
        $post->user_id = $id;
        $post->foodname = $request->get('foodname');
        $post->orgname = $request->get('orgname');
        $post->no_of_people = $request->get('no_of_people');
        $post->date = $request->get('date');
        $post->info = $request->get('info');
        $post->status = "2";
        $post->request = "0";
        $post->favourite = "0";
        
        $post->save();

        return redirect ('home')->with('message', 'Successfully sent a request');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
