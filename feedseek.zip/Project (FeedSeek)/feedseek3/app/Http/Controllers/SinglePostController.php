<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Donation;
use App\profile;
use App\Requests;
use App\User;
use Auth;

class SinglePostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        $post = Donation::find($id);
        $requests = Requests::all();
        $user = User::find(Auth::id());
        $i = 0;
        
        return view('single_post', compact('post', 'requests', 'user', 'i'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function confirm($id)
    {

        $req = new Requests;
        $post = Donation::find($id);

        $uid = $post['user_id'];
        $uid2 = Auth::id();
        /*dd($uid2);*/

        $req->user_id = $uid2;
        $req->requested_to = $uid;
        $req->on_donation_id = $id;
        $req->status = "1";
        $req->save();



        
        $post = Donation::find($id);
        $post1 = $post['request'];
        
        $post->request = $post1+1;
        
        $post->save();

        return redirect()->back()->with('seccess', ['done']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
