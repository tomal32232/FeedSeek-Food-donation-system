<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\profile;
use Auth;
use File;

class ProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::find(Auth::id());
        return view('profile',compact('user'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
   }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find(Auth::id());
        return view ('edit_profile',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $profile=profile::find($id);
        $profile->full_name = $request->get('full_name');
        $profile->org_name = $request->get('org_name');
        $profile->designation = $request->get('designation');
        $profile->address = $request->get('address');
        $profile->phone_no = $request->get('phone_no');
        $profile->additional_info = $request->get('additional_info');

        if($file = $request->file('image')){
            $fileName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $fullFileName = $fileName."-".time().".".$file->getClientOriginalExtension();
            $destinationPath = public_path().'/images/profile_photos/' ;
            $file->move($destinationPath,$fullFileName);
            $profile->image = $fullFileName;
        }

        $profile->save();

        return redirect ('profile')->with('message', 'Successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function delete($id)
    {
        $profile=profile::find($id);
        $destinationPath = public_path().'/images/profile_photos/' ;
        File::delete($destinationPath.$profile->image);
        $profile->image = null;
        $profile->save();

        return back();
    }
}
