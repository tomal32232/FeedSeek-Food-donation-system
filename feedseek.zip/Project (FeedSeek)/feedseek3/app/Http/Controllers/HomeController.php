<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Donation;
use App\profile;
use App\Requests;
use App\User;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       /* $this->middleware('auth');*/
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $posts = Donation::all();
        $requests = Requests::all();
        $count = Requests::count();
        $user = User::find(Auth::id());
        $i = 0;
        return view('home', compact('posts', 'requests', 'user', 'i', 'count'));
    }

    
}
