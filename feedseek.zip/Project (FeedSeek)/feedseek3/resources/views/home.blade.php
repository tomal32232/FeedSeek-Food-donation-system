@extends('layouts.app')
@section('content')



<!-- start success message -->
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
<!-- start success message -->



<!-- start cover image section -->
<div class="site-blocks-cover" style="background-image: url(images/cover.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
  <div class="container">
    <div class="row row-custom align-items-center">
      <div class="col-md-10">
        <h1 class="mb-2 text-black w-75"><span class="font-weight-bold">We Can</span> Help To Save The World</h1>
        <div class="job-search">
          <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active py-3" id="pills-job-tab" data-toggle="pill" href="#pills-job" role="tab" aria-controls="pills-job" aria-selected="true">Find Donor</a>
            </li>
            <li class="nav-item">
              <a class="nav-link py-3" id="pills-candidate-tab" data-toggle="pill" href="#pills-candidate" role="tab" aria-controls="pills-candidate" aria-selected="false">Find Recepient</a>
            </li>
          </ul>
          <div class="tab-content bg-white p-4 rounded" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-job" role="tabpanel" aria-labelledby="pills-job-tab">
              <form action="#" method="post">
                <div class="row">
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control" placeholder="eg. Web Developer">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="select-wrap">
                      <span class="icon-keyboard_arrow_down arrow-down"></span>
                      <select name="" id="" class="form-control">
                        <option value="">Category</option>
                        <option value="fulltime">Full Time</option>
                        <option value="fulltime">Part Time</option>
                        <option value="freelance">Freelance</option>
                        <option value="internship">Internship</option>
                        <option value="internship">Termporary</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control form-control-block search-input" id="autocomplete" placeholder="Location" onFocus="geolocate()">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="submit" class="btn btn-primary btn-block" value="Search">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="pills-candidate" role="tabpanel" aria-labelledby="pills-candidate-tab">
              <form action="#" method="post">
                <div class="row">
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control" placeholder="eg. Carl Smith">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="select-wrap">
                      <span class="icon-keyboard_arrow_down arrow-down"></span>
                      <select name="" id="" class="form-control">
                        <option value="">Category</option>
                        <option value="fulltime">Full Time</option>
                        <option value="fulltime">Part Time</option>
                        <option value="freelance">Freelance</option>
                        <option value="internship">Internship</option>
                        <option value="internship">Termporary</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="text" class="form-control form-control-block search-input" id="autocomplete" placeholder="Location" onFocus="geolocate()">
                  </div>
                  <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                    <input type="submit" class="btn btn-primary btn-block" value="Search">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end cover image section -->



<!-- start guest section -->
@guest
<div class="site-section bg-light">
  <div class="container">
    <div class="row justify-content-start text-left mb-5">
      <div class="col-md-9" data-aos="fade">
        <h2 class="font-weight-bold text-black">Recent Post</h2>
      </div>
      <div class="col-md-3" data-aos="fade" data-aos-delay="200">
        <a href="{{ route('receive_food') }}" class="btn btn-primary py-3 btn-block"><span class="h5"></span> I need food</a>
      </div>
    </div>
    <div class="row" data-aos="fade">
      <div class="col-md-12">
      @if (count($posts) > 0)
        @foreach ($posts as $post)
          @if ($post->status==1 || $post->status==2)
            <div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
              <div class="mb-4 mb-md-0 mr-5">
                <div class="job-post-item-header d-flex align-items-center">
                  <h2 class="mr-3 text-black h4">{{ $post->foodname }}</h2>
                  @if ($post->status==1)
                    <h5 style="color: red"><i class="fas fa-donate"></i> For donation</h5>
                  @else
                    <h5 style="color: red"><i class="fas fa-handshake"></i> Recipient</h5>
                  @endif
                </div>
                <div class="job-post-item-header d-flex align-items-center">
                  <div><h5>About {{ $post->no_of_people }} people</h5></div>
                  @if ($post->status==1)
                    <div><h6>&nbsp&nbsp&nbsp&nbsp&nbspMaximum Date: {{ $post->date }}</h6></div>
                  @else
                    <div><h6>&nbsp&nbsp&nbsp&nbsp&nbspOn: {{ $post->date }}</h6></div>
                  @endif
                </div>
                <div class="job-post-item-body d-block d-md-flex">
                  <div class="badge-wrap">
                    <span class="bg-primary text-white badge py-2 px-2" style="border-radius: 2px">{{ $post->orgname }}</span>
                  </div>
                </div>
                <div class="job-post-item-body d-block d-md-flex">
                  <div class="badge-wrap">
                    Posted by: {{ $post->user['username'] }}, {{ $post->created_at->diffForHumans() }}
                  </div>
                </div>
                <div class="job-post-item-header d-flex align-items-center">
                  <div><h5><i class="fas fa-map-marker"></i> {{ $post->user->profile['address'] }}</h5></div>
                </div>
              </div>

              <div class="ml-auto mt-auto">
                <a href="#" class="btn btn-secondary rounded-circle btn-favorite text-gray-500"><span class="icon-heart"></span></a>
                <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">View details</a>
                @if ($post->status==1)
                <a href="{{route ('single_post.confirm', $post->id)}}" class="btn btn-primary py-2">I want to receive</a>
                @else
                <a href="job-single.html" class="btn btn-primary py-2">I want to donate</a>
                @endif
              </div>
            </div>
          @else
          @endif
        @endforeach
      @else
      @endif
      </div>
    </div>
      

        

    <div class="row mt-5">
      <div class="col-md-12 text-center">
        <div class="site-block-27">
          <ul>
            <li><a href="#"><i class="icon-keyboard_arrow_left h5"></i></a></li>
            <li class="active"><span>1</span></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li><a href="#"><i class="icon-keyboard_arrow_right h5"></i></a></li>
          </ul>
        </div>
      </div>
    </div>


  </div>
</div>

@endguest
<!-- end guest section -->











<!-- start auth section -->
@auth
<div class="site-section bg-light">
  <div class="container">
    <div class="row justify-content-start text-left mb-5">
      <div class="col-md-9" data-aos="fade">
        <h2 class="font-weight-bold text-black">Recent Post</h2>
      </div>
      <div class="col-md-3" data-aos="fade" data-aos-delay="200">
        <a href="{{ route('receive_food') }}" class="btn btn-primary py-3 btn-block"><span class="h5"></span> I need food</a>
      </div>
    </div>
    <!-- start post section -->
    <div class="row" data-aos="fade">
      <div class="col-md-12">
      @if (count($posts) > 0)
        @foreach ($posts as $post)
          @if ($post->status==1 || $post->status==2)
            <div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
              <div class="mb-4 mb-md-0 mr-5">
                <div class="job-post-item-header d-flex align-items-center">
                  <h2 class="mr-3 text-black h4">{{ $post->foodname }}</h2>
                  @if ($post->status==1)
                    <h5 style="color: red"><i class="fas fa-donate"></i> For donation</h5>
                  @else
                    <h5 style="color: red"><i class="fas fa-handshake"></i> Recipient</h5>
                  @endif
                </div>
                <div class="job-post-item-header d-flex align-items-center">
                  <div><h5>About {{ $post->no_of_people }} people</h5></div>
                  @if ($post->status==1)
                    <div><h6>&nbsp&nbsp&nbsp&nbsp&nbspMaximum Date: {{ $post->date }}</h6></div>
                  @else
                    <div><h6>&nbsp&nbsp&nbsp&nbsp&nbspOn: {{ $post->date }}</h6></div>
                  @endif
                </div>
                <div class="job-post-item-body d-block d-md-flex">
                  <div class="badge-wrap">
                    <span class="bg-primary text-white badge py-2 px-2" style="border-radius: 2px">{{ $post->orgname }}</span>
                  </div>
                </div>
                <div class="job-post-item-body d-block d-md-flex">
                  <div class="badge-wrap">
                    Posted by: {{ $post->user['username'] }}, {{ $post->created_at->diffForHumans() }}
                  </div>
                </div>
                <div class="job-post-item-header d-flex align-items-center">
                  <div><h5><i class="fas fa-map-marker"></i> {{ $post->user->profile['address'] }}</h5></div>
                </div>
              </div>

              <div class="ml-auto mt-auto">
                <a href="#" class="btn btn-secondary rounded-circle btn-favorite text-gray-500"><span class="icon-heart"></span></a>
                
                @if ($post->status==1)
                  @if (count($requests) > 0)
                    @foreach ($requests as $request)
                      @if($user->id == $request->user_id && $post->id==$request->on_donation_id)
                        @php
                          $i=1;
                        @endphp
                      @else
                        @php
                          $i=2;
                        @endphp
                      @endif
                  
                      @if($post->user_id == $user->id)
                        @php
                          $i=3;
                        @endphp
                      @endif
                    @endforeach
                  @else
                    @php
                      $i=2;
                    @endphp
                  @endif

                  @if($i == 1)
                    <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">View details</a>
                    <a href="#" class="btn btn-danger py-2 disabled" > Request sent</a>
                  @else
                  @endif
                  @if($i == 2)
                    <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">View details</a>
                    <a href="{{route ('single_post.confirm', $post->id)}}" class="btn btn-primary py-2">I want to receive</a>
                  @else
                  @endif
                  @if($i == 3)
                    <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">Edit your post</a>
                    
                  @else
                  @endif
                @endif



                @if ($post->status==2)
                  @if (count($requests) > 0)
                    @foreach ($requests as $request)
                      @if($user->id == $request->user_id && $post->id==$request->on_donation_id)
                        @php
                          $i=1;
                        @endphp
                      @else
                        @php
                          $i=2;
                        @endphp
                      @endif
                  
                      @if($post->user_id == $user->id)
                        @php
                          $i=3;
                        @endphp
                      @endif
                    @endforeach
                  @else
                    @php
                      $i=2;
                    @endphp
                  @endif

                  @if($i == 1)
                    <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">View details</a>
                    <a href="#" class="btn btn-danger py-2 disabled" > Request sent</a>
                  @else
                  @endif
                  @if($i == 2)
                    <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">View details</a>
                    <a href="{{route ('single_post.confirm', $post->id)}}" class="btn btn-primary py-2">I want to donate</a>
                  @else
                  @endif
                  @if($i == 3)
                    <a href="{{route ('single_post.view', $post->id)}}" class="btn btn-primary py-2">Edit your post</a>
                    
                  @else
                  @endif
                @endif
              </div>
            </div>
          @else
          @endif
        @endforeach
      @else
      @endif
      </div>
    </div>
    <!-- end post section -->
      

        

    <div class="row mt-5">
      <div class="col-md-12 text-center">
        <div class="site-block-27">
          <ul>
            <li><a href="#"><i class="icon-keyboard_arrow_left h5"></i></a></li>
            <li class="active"><span>1</span></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li><a href="#"><i class="icon-keyboard_arrow_right h5"></i></a></li>
          </ul>
        </div>
      </div>
    </div>


  </div>
</div>
@endauth
<!-- end auth section -->
@endsection
