
@extends('layouts.app')

@section('content')

<div class="site-section bg-light">
  <div class="container">
    <div class="row justify-content-start text-left mb-5">
      <div class="col-md-9" data-aos="fade">
        <h2 class="font-weight-bold text-black">My Post</h2>
      </div>
      <div class="col-md-3" data-aos="fade" data-aos-delay="200">
        <a href="#" class="btn btn-primary py-3 btn-block"><span class="h5">+</span> Create new</a>
      </div>
    </div>

    <div class="row" data-aos="fade">
      <div class="col-md-12">
        @if (count($posts) > 0)
          @foreach ($posts as $post)
            @if($post->user_id == Auth::user()->id && ($post->status==1 || $post->status==2))
            	<div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
                <div class="mb-4 mb-md-0 mr-5">
               		<div class="job-post-item-header d-flex align-items-center">
                 		<h2 class="mr-3 text-black h4">{{ $post->foodname }}</h2>
                 			@if ($post->status==1)
                 				<h5 style="color: red"><i class="fas fa-user-alt"></i>For donation</h5>
                 			@else
                 				<h5 style="color: red"><i class="fas fa-user-alt"></i>Recipient</h5>
                 			@endif
                	</div>
               		<div class="job-post-item-header d-flex align-items-center">
                 		<div>
                      <h5>About {{ $post->no_of_people }} people</h5>
                    </div>
                 			@if ($post->status==1)
                 		    <div>
                          <h6>&nbsp&nbsp&nbsp&nbsp&nbspMaximum Date: {{ $post->date }}</h6>
                        </div>
                 			@else
                 				<div>
                          <h6>&nbsp&nbsp&nbsp&nbsp&nbspOn: {{ $post->date }}</h6>
                        </div>
                 			@endif
                	</div>
               		<div class="job-post-item-body d-block d-md-flex">
                 		<div class="badge-wrap">
                  		<span class="bg-primary text-white badge py-2 px-2" style="border-radius: 2px">{{ $post->orgname }}</span>
                    </div>
                 	</div>
               		<div class="job-post-item-header d-flex align-items-center">
                 		<div>
                      <h5><i class="fas fa-map-marker"></i> {{ $post->user->profile['address'] }}</h5>
                    </div>
                    <div class="job-post-item-header d-flex align-items-center">
                      <div>
                        <h5>&nbsp&#46&nbspRequest submitted: {{ $post->request }}</h5>
                      </div>
                    </div>
                 	</div>
              	</div>

              	<div class="ml-auto mt-auto">
                	<a href="job-single.html" class="btn btn-primary py-2">Edit</a>
                	<a href="job-single.html" class="btn btn-danger py-2">Delete</a>
                </div>
           		</div>
           			
           	@else
           	@endif
          @endforeach

        @else
  		  @endif

      </div>
    </div>
      

    <div class="row mt-5">
      <div class="col-md-12 text-center">
        <div class="site-block-27">
          <ul>
            <li><a href="#"><i class="icon-keyboard_arrow_left h5"></i></a></li>
            <li class="active"><span>1</span></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li><a href="#"><i class="icon-keyboard_arrow_right h5"></i></a></li>
          </ul>
        </div>
      </div>
    </div>


  </div>
</div>
@endsection

