@extends('layouts.app')
@section('content')

<!-- start success message -->
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
<!-- start success message -->


<section class="home_banner_area">
           	<div class="container box_1620">
           		<div class="banner_inner d-flex align-items-center">
					<div class="banner_content">
						<div class="media">
							<div class="d-flex">
								@if($user->profile['image'])
								<img src="images/profile_photos/{{ $user->profile['image'] }}" alt="" style="max-height: 500px; max-width: 500px;object-fit: cover;">
								@else
								<a href="{{ route('edit_profile', Auth::user()->id) }}"><img src="images/errors/upload_photo.png" alt="" style="max-height: 500px; max-width: 500px;object-fit: cover;"></a>
								@endif
							</div>
							<div class="media-body">
								
								<div class="personal_text">
									<h6>Name:</h6>
									@if($user->profile['full_name'])
									<h4>{{ $user->profile['full_name'] }}</h4>
									@else
									<a href="{{ route('edit_profile', Auth::user()->id) }}">Edit profile</a>
									@endif
									<hr>
									<h6>Organization or restaurant:</h6>
									@if($user->profile['org_name'])
									<h4>{{ $user->profile['org_name'] }}</h4>
									@else
									<a href="{{ route('edit_profile', Auth::user()->id) }}">Edit profile</a>
									@endif
									<hr>
									<h6>Address:</h6>
									@if($user->profile['address'])
									<h4>{{ $user->profile['address'] }}</h4>
									@else
									<a href="{{ route('edit_profile', Auth::user()->id) }}">Edit profile</a>
									@endif
									<hr>
									
									<ul class="list basic_info">
										<li><a href="#"><i class="far fa-clock"></i>Member since: {{ $user->profile['created_at']->format('F, Y') }}</a></li>
										<li><a href="#"><i class="fas fa-phone"></i></i> {{ $user->profile['phone_no'] }} </a></li>
										<li><a href="#"><i class="far fa-envelope-open"></i> {{ $user->email }}</a></li>
									</ul>
									<ul class="list personal_social" style="float: right;">
										<li><a href="#"><i class="fab fa-facebook-square"></i></a></li>
										<li><a href="#"><i class="fab fa-twitter-square"></i></a></li>
										<li><a href="#"><i class="fab fa-linkedin"></i></a></li>
									</ul>
									<ul>
									<a href="{{ route('edit_profile', Auth::user()->id) }}"  style="float: right; margin-top: 40px;">Edit profile  <i class="fas fa-user-edit"></i></a>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </section>
@endsection