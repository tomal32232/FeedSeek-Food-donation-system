@extends('layouts.app')
@section('content')
<section class="home_banner_area">
           	
	<div class="container mt-5">
		<div class="row">
			<div class="col">
				<div class="personal_text">
					<h6>Food Name:</h6>
					<h4>{{ $post->foodname }}</h4>
					<hr>
											

					<h6>Organization:</h6>
					<h4>{{ $post->orgname }}</h4>
					<hr>
											

					<h6>For how many people:</h6>
					<h4>{{ $post->no_of_people }}</h4>
					<hr>

					<h6>Expire date:</h6>
					<h4>{{ $post->date }}</h4>
					<hr>

					<h6>Additional info:</h6>
					<h4>{{ $post->info }}</h4>
					<hr>

					<h6>Request submitted</h6>
					<h4>{{ $post->request }}</h4>
					<hr>
				</div>
			</div>



			<div class="col">
				<div class="personal_text">
					<h6>Donor Name:</h6>
					<h4>{{ $post->user->profile['full_name'] }}</h4>
					<hr>
											

					<h6>Organization or restaurant:</h6>
					<h4>{{ $post->user->profile['org_name'] }}</h4>
					<hr>
											

					<h6>Address:</h6>
					<h4>{{ $post->user->profile['address'] }}</h4>
					<hr>

					<h6>Phone:</h6>
					<h4>{{ $post->user->profile['phone_no'] }}</h4>
					<hr>

					<h6>Email:</h6>
					<h4>{{ $post->user['email'] }}</h4>
					<hr>

					<h6>Member since:</h6>
					<h4>{{$post->user->profile['created_at']->format('F, Y')}}</h4>
					<hr>
				</div>
			</div>

		</div>
				
	@if (count($requests) > 0)
		@foreach ($requests as $request)
				
			@if($user->id == $request->user_id && $post->id==$request->on_donation_id)
				@php
					$i=1;
				@endphp
			@else
				@php
					$i=2;
				@endphp
			@endif
		@endforeach
	@else
		@php
			$i=2;
		@endphp
	@endif

			@if($i == 1)
			<a href="#" class="btn btn-danger py-3 btn-block disabled" ><span class="h5">+</span> Request sent</a>
			@else
			@endif
			@if($i == 2)
			<a href="{{route ('single_post.confirm', $post->id)}}" class="btn btn-primary py-3 btn-block"><span class="h5">+</span> Confirm</a>
			@else
			@endif
			
				{{$i}}
			
	</div>
</section>
@endsection